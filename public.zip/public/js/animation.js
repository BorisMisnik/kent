var action = function () {

	var that = {};
	var container = $('.container-fluid');

	that.arrow = function(){

		var tweenArrwo = new TimelineLite();
		TweenMax.to($('.arrow-start'), .6, {top:"-5px",
                       repeat:-1, yoyo:true});

		return that;	
	};

	that.scrolTop = function(){

		if( $('#main').is('.now') || container.is(':animated') ) return;

		var yScrol = container.scrollTop() - container.height();
		var scroll = yScrol > 0 ? yScrol : 0;

		container.animate({'scrollTop' : scroll},1000);

		this.top = true;
		this.bottom = false;
		this.selectAnimation();

	};
	
	that.scrollBotom = function(){
		
		if( $('#profile').is('.now') || container.is(':animated') ) return;

		var yScrol = container.scrollTop() + container.height();

		container.animate({'scrollTop' : yScrol},1000);

		this.top = false;
		this.bottom = true;
		this.selectAnimation();

	};

	that.selectAnimation = function(){

		if( this.top && $('.now').prev() ) {

			$('.now')
				.removeClass('now')
				.prev()
				.addClass('now');

		}
		else if( this.bottom && $('.now').next() ) {

			$('.now')
				.removeClass('now')
				.next()
				.addClass('now');
		}

		var animationName = $('.now').data('animation');

		switch ( animationName ){

			case 'first' :
				console.log('first');
				break;
			case 'second' :
				console.log('second');
				break;
			case 'third' :
				console.log('third');
				break;
			default :
				console.log('first');
		}

	};

	return that;
};

$(document).ready(function(){

	var animation = action();
	var container = $('.container-fluid');
	var sections = [
		$('#main'),$('#mainSecond'),$('#profile')
	];
	animation.arrow();

	var t = new Date().getTime(),l;
	container.on({
		mousewheel : function(event, delta){
				
			if(delta > 0){
	    		animation.scrolTop();
		    }
		    else{
		   		animation.scrollBotom();
		    }
			
		},

		scroll : function(){

			$this = $(this);
			var now = new Date().getTime();

			if(now - l > 1000){
				$this.trigger('scrollStart');
				l = now;
			}

			clearTimeout(t);
			t = setTimeout(function(){
				$this.trigger('scrollEnd')
			},300);

		},	

		scrollStart : function(){

			// console.log('Scroll Start');
		},

		scrollEnd : function(){

			// console.log('Scroll end');
			var name = $('.now').attr('id');
			$('.nav-site a')
				.each(function(){

					if($(this).data('slide') === name){

						$('li.active').removeClass('active');
						$(this).parent().addClass('active');

						return;
					}

				});
		}

	});

	$('.nav-site')
		.find('li')
		.on({
			click : function(e){

				e.preventDefault();

				$a = $(this).find('a');
				var slide = $a.data('slide');
				var y = $('#' + slide).offset().top;

				container
					.animate({'scrollTop' : y},1000);
		
			}
		});


	$('.scrollButton')
		.find('a')
		.on({
			click : function(e){

				e.preventDefault();

				$this  = $(this);

				if($this.is('.prev')){
					animation.scrolTop();
				}
				else{
					animation.scrollBotom();
				}
			}	
		});

	$(document).on({
		keydown : function(e){

			var up = 38,
				down = 40;

			if (e.keyCode == up) {
				// console.log('Scroll Top');
				animation.scrolTop();
	   		}
		   	else if (e.keyCode == down) {
		   		// console.log('Scroll Bottom');
		   		animation.scrollBotom();
		    }

		}
	});

})